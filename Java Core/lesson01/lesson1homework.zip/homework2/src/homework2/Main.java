package homework2;

public class Main {

    public static void main(String[] args) {
        byte numByte = 127;
        short numShort = 458;
        int numInt = 3458000;
        long numLong = 88783665524442L;
        float numFloat = 654.1110f;
        double numDouble = 1256.87651;
        char ch = '&';
        String str = "Второе задание.";
        boolean bool = true;
    }
}
